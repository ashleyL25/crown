<div id="g5core_menu_popup" class="g5core-menu-popup mfp-hide mfp-with-anim">
	<?php G5CORE()->get_template( 'header/desktop/menu.php', array(
			'menu_class' => 'main-menu menu-popup'
	) ); ?>
</div>