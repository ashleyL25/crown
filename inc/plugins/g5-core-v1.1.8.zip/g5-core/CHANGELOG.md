Changelog
=========
#### 1.1.8 - December 29, 2020
* Fix style line ending both DOS and UNIX

#### 1.1.7 - December 19, 2020
* Update setting mobile content padding

#### 1.1.6 - November 17, 2020
* Update custom css when ajax post

#### 1.1.5 - October 31, 2020
* Fix social share

#### 1.1.4 - October 13, 2020
* Add layout metro 

#### 1.1.3 - October 08, 2020
* Fix clear cache listing 

#### 1.1.2 - September 26, 2020
* Fix remove default google font 

#### 1.1.1 - September 22, 2020
* Fix error register script bootstrap select 

#### 1.1.0 - September 18, 2020
* Update Smart Framework version 2.0

#### 1.0.9 - July 08, 2020
* Add filter option name
* Fix footer fixed 

#### 1.0.8 - March 28, 2020
* Fix get body class off header vertical 

#### 1.0.0 - February 25, 2017
* Inital Version