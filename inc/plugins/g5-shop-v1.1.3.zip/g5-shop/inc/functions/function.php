<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
G5SHOP()->load_file(G5SHOP()->plugin_dir('inc/functions/helper.php'));
G5SHOP()->load_file(G5SHOP()->plugin_dir('inc/functions/template.php'));
