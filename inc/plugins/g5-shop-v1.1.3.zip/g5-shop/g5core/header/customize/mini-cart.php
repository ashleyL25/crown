<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<div class="g5shop__mini-cart woocommerce">
    <?php g5shop_template_mini_cart_icon(); ?>
    <div class="widget_shopping_cart_content">
    </div>
</div>

