Changelog
=========
### 1.0.7 - December 29, 2020
* Fix style line ending both DOS and UNIX

### 1.0.6 - September 21, 2020
* Fix set post per page for archive blog

### 1.0.5 - July 08, 2020
* Add config item custom class