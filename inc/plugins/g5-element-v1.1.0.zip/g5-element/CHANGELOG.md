Changelog
=========
#### 1.1.0 - December 29, 2020
* Fix style line ending both DOS and UNIX

#### 1.0.9 - October 16, 2020
* Update layout metro of shortcode gallery
* Add fillter g5element_map_style_config

#### 1.0.8 - July 28, 2020
* Update param image hover in shortcode image box

#### 1.0.7 - June 30, 2020
* Fix custom color hover

#### 1.0.6 - April 03, 2020
* Fix edit page with WPBakery Page Builder in backend

#### 1.0.5 - March 28, 2020
* Fix edit page with WPBakery Page Builder in frontend
* Fix error enqueue shortcode assets with php 7.4 

#### 1.0.0 - February 25, 2017
* Inital Version