<?php
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('inc/functions/helper.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('inc/functions/vc-sources.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('inc/functions/vc-map.php'));
G5ELEMENT()->load_file(G5ELEMENT()->plugin_dir('inc/functions/template.php'));