(function ($) {
	"use strict";
	var G5Element_Slider_Container = {
		init: function () {
			$('.gel-slider-container').each(function () {

			});
		},
	};
	$(document).ready(function () {
        G5Element_Slider_Container.init();
	});
})(jQuery);