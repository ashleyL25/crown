Changelog
=========
### 1.0.5 - December 29, 2020
* Fix style line ending both DOS and UNIX